import sys
import os

# Ajustar ruta para permitir importación desde "lambda/audiencias"
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(CURRENT_DIR, "../../../"))
sys.path.append(ROOT_DIR)

from lambda.audiencias import handler


def test_health_ok():
    event = {"routeKey": "GET /health"}
    resp = handler.lambda_handler(event, None)

    assert resp["statusCode"] == 200
    assert "status" in resp["body"]
